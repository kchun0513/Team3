package sudoku;

import java.awt.event.*;
import javax.swing.*;

public class SudokuButton extends JButton implements ActionListener {
	private SudokuBoard board;
	private InputNumber number;
	private SudokuFrame frame;
	private int x;
	private int y;

	/** Constructor - SudokuButton 스도쿠 보드의 칸 하나 생성
	 * @param a - 스도쿠 칸의 위치를 나타내는 첫 번째 인덱스
	 * @param b - 스도쿠 칸의 위치를 나타내는 두 번째 인덱스
	 * @param s - SudokuBoard 객체
	 * @param f - SudokuFrame 객체
	 * @param n - InputNumber 객체 */
	public SudokuButton(int a, int b, SudokuBoard s, SudokuFrame f, InputNumber n) {
		x = a;
		y = b;
		number = n;
		board = s;
		frame = f;
		addActionListener(this);
	}
	
	/** actionPerformed - 버튼이 눌릴 경우 선택된 숫자가 답인지 체크하고 프레임 새로고침 */
	public void actionPerformed(ActionEvent e) {
		int n = number.valueOf();
		board.checkAnswer(x, y, n);
		frame.update();
	}
}
