package sudoku;

import javax.swing.*;

public class SudokuController {
	private SudokuFrame frame;
	private SudokuBoard board;

	/** Constructor - SudokuController 객체 생성과 초기화 */
	public SudokuController() {
		String board_size = JOptionPane.showInputDialog("4: 4x4 사이즈, 6: 6x6 사이즈, 9: 9x9 사이즈");
		while (!(board_size.equals("4") || board_size.equals("6") || board_size.equals("9"))) {
			board_size = JOptionPane.showInputDialog("잘못된 입력입니다. 다시 입력해주세요. 4: 4x4 사이즈, 6: 6x6 사이즈, 9: 9x9 사이즈");
		}
		String difficulty = JOptionPane.showInputDialog("1: 쉬움, 2: 보통, 3: 어려움");
		while (!(difficulty.equals("1") || difficulty.equals("2") || difficulty.equals("3"))) {
			difficulty = JOptionPane.showInputDialog("잘못된 입력입니다. 다시 입력해주세요. 1: 쉬움, 2: 보통, 3: 어려움");
		}
		int b = Integer.parseInt(board_size);
		int d = Integer.parseInt(difficulty);
		board = new SudokuBoard(d, b);
		frame = new SudokuFrame(b, board, new InputNumber());
	}
	
	/** play - 스도쿠 게임 실행과 종료 */
	public void play() {
		long t1 = System.currentTimeMillis();
		while (board.returnEmpty() > 0) {
			frame.update();
		}
		long t2 = System.currentTimeMillis();
		JOptionPane.showMessageDialog(null, "다음에 또 만나요! \n" + "난이도: " + board.returnDif()
									  + "\n클리어 시간: " + (t2-t1)/1000.00 + " sec");
	}
}