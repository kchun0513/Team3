package sudoku;

/** InputNumber models a selected number of sudoku. */
public class InputNumber {
	private int number;
	
	/** Constructor InputNumber - 스도쿠 보드에 입력할 숫자의 초기값을 1로 지정 */
	public InputNumber() {
		number = 1;
	}
	
	/** select - 스도쿠 보드에 입력할 숫자를 변경
	 * @param n - 적용할 숫자 */
	public void select(int n) {
		number = n;
	}
	
	/** 현재 스도쿠 보드에 입력할 숫자를 리턴 */
	public int valueOf() {
		return number;
	}
}