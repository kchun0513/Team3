package sudoku;

public class SudokuStarter {
	public static void main(String[] args) {
		new SudokuController().play();
	}
}