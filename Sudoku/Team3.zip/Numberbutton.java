package sudoku;

import java.awt.event.*;
import javax.swing.*;

public class Numberbutton extends JButton implements ActionListener {
	private InputNumber number;
	
	/** Constructor - Numberbutton 스도쿠 보드의 숫자 선택 버튼 하나 생성
	 * @param n - InputNumber 객체
	 */
	public Numberbutton(InputNumber n) {
		number = n;
		addActionListener(this);
	}
	
	/** actionPerformed - 버튼이 눌릴 경우 해당하는 숫자로 입력할 숫자를 선택 */
	public void actionPerformed(ActionEvent e) {
		String s = getText();
		number.select(Integer.parseInt(s));
	}
}